#import clean data into python


#pip install pymysql


import pandas as pd
from sqlalchemy import create_engine
import mysql.connector

# Connect to MySQL using mysql-connector-python


engine = create_engine('mysql+mysqlconnector://user9:Win12345678@localhost/ASDproject')


database_url = 'mysql+pymysql://user9:Win12345678@localhost/ASDproject'
engine = create_engine(database_url)


# Example query to fetch data from a table

query = 'SELECT * FROM clean_data'
clean_data = pd.read_sql(query, engine)

# Display the DataFrame
print(clean_data.head())

# Display the DataFrame
print(clean_data)

clean_data.info()
clean_data.isna()
clean_data.describe()
clean_data.shape
clean_data.dtypes

#import video_details into python

import pandas as pd

query = 'SELECT * FROM video_details'
video_details = pd.read_sql(query, engine)

# Display the DataFrame
print(video_details.head())
print(video_details)

# Replace 'your_file.csv' with the correct file name and path
file_path = '/Users/sankar/Desktop/Project ASD/Dataset 2/video_details.csv'

# Read the CSV file into a DataFrame
video_details = pd.read_csv(file_path)

# Display the DataFrame
print(video_details)

video_details.info()
video_details.isna()
video_details.describe()
video_details.shape
video_details.dtypes


#Before EDA
#FIRST MOMENT BUSINESS DECISION

#To calculate MEAN 

clean_data.duration.mean()
clean_data.probability.mean()
clean_data.fps.mean()

video_details.length.mean()


#To calculate MEDIAN 
clean_data.duration.median()
clean_data.probability.median()
clean_data.fps.median()

video_details.length.median()



#To calculate MODE 


clean_data.duration.mode()
clean_data.probability.mode()
clean_data.fps.mode()

video_details.length.mode()




## SECOND MOMENT BUSINESS DECISION / MEASURES OF DISPERSION

#To find Variance

clean_data.duration.var()
clean_data.probability.var()
clean_data.fps.var()

video_details.length.var()


#To find Standard deviation

clean_data.duration.std()
clean_data.probability.std()
clean_data.fps.std()

video_details.length.std()



#To find Range(Max-Min)

range = max(clean_data.duration) - min(clean_data.duration)
print(range)

range = max(clean_data.probability) - min(clean_data.probability)
print(range)

range = max(clean_data.fps) - min(clean_data.fps)
print(range)

range = max(video_details.length) - min(video_details.length)
print(range)


## THIRD MOMENT BUSINESS DECISIONS - Skewness


clean_data.duration.skew()
clean_data.probability.skew()
clean_data.fps.skew()

video_details.length.skew()

##FOURTH MOMENT BUSINESS DECISION - Kurtosis

clean_data.duration.kurtosis()
clean_data.probability.kurtosis()
clean_data.fps.kurtosis()

video_details.length.kurtosis()


#Data preprocessing 

#To find Missing values in clean_data.csv

import pandas as pd

clean_data = '/Users/sankar/Desktop/Project ASD/clean_data.csv'

# Read the CSV file into a DataFrame
clean_data = pd.read_csv(clean_data)

# Find missing values in the DataFrame
missing_values = clean_data.isnull()

# Count the number of missing values in each column
missing_counts = missing_values.sum()

# Display the missing values counts
print("Missing values counts per column:")
print(missing_counts)

#To find missing values in video_details.csv

import pandas as pd


video_details = '/Users/sankar/Desktop/Project ASD/Dataset 2/video_details.csv'

# Read the CSV file into a DataFrame
video_details = pd.read_csv(video_details)

# Find missing values in the DataFrame
missing_values = clean_data.isnull()

# Count the number of missing values in each column
missing_counts = missing_values.sum()

# Display the missing values counts
print("Missing values counts per column:")
print(missing_counts)


#To find the duplicate rows in clean_data.csv


import pandas as pd


clean_data = '/Users/sankar/Desktop/Project ASD/clean_data.csv'

# Read the CSV file into a DataFrame
clean_data = pd.read_csv(clean_data)

# Find duplicates based on all columns
duplicates_all = clean_data[clean_data.duplicated()]

# Find duplicates based on specific columns
# Replace 'column1', 'column2', etc. with the actual column names
columns_to_check = ['uid', 'probability','fps']
duplicates_subset = clean_data[clean_data.duplicated(subset=columns_to_check)]

# Display the duplicates
print("All duplicates:")
print(duplicates_all)

print("\nDuplicates based on specific columns:")
print(duplicates_subset)

#To find the duplicate rows in video_details.csv


import pandas as pd


video_details = '/Users/sankar/Desktop/Project ASD/Dataset 2/video_details.csv'

# Read the CSV file into a DataFrame
video_details = pd.read_csv(video_details)

# Find duplicates based on all columns
duplicates_all = video_details[video_details.duplicated()]

# Find duplicates based on specific columns
# Replace 'column1', 'column2', etc. with the actual column names
columns_to_check = ['name', 'length']
duplicates_subset = video_details[video_details.duplicated(subset=columns_to_check)]

# Display the duplicates
print("All duplicates:")
print(duplicates_all)

print("\nDuplicates based on specific columns:")
print(duplicates_subset)

#To find outliers in clean_data.csv


import pandas as pd


clean_data = '/Users/sankar/Desktop/Project ASD/clean_data.csv'

# Read the CSV file into a DataFrame
clean_data = pd.read_csv(clean_data)

# Specify the column(s) for which you want to detect outliers
# For example, let's consider a column named 'column_name'
column_name = 'probability'

# Calculate the IQR for the specified column
Q1 = clean_data[column_name].quantile(0.25)
Q3 = clean_data[column_name].quantile(0.75)
IQR = Q3 - Q1

# Define a threshold to identify outliers
# You can adjust this threshold based on your specific requirements
outlier_threshold = 1.5

# Find outliers using the IQR method
outliers = (clean_data[column_name] < Q1 - outlier_threshold * IQR) | (clean_data[column_name] > Q3 + outlier_threshold * IQR)

# Display the rows containing outliers
outliers_data = clean_data[outliers]
print("Rows with outliers:")
print(outliers_data)

# Display summary statistics for the column, including potential outliers
summary_stats = clean_data[column_name].describe()
print("\nSummary statistics for the column:")
print(summary_stats)


#To find outliers in video_details.csv


import pandas as pd


video_details = '/Users/sankar/Desktop/Project ASD/Dataset 2/video_details.csv'

# Read the CSV file into a DataFrame
video_details = pd.read_csv(video_details)

# Specify the column(s) for which you want to detect outliers
# For example, let's consider a column named 'column_name'
column_name = 'length'

# Calculate the IQR for the specified column
Q1 = video_details[column_name].quantile(0.25)
Q3 = video_details[column_name].quantile(0.75)
IQR = Q3 - Q1

# Define a threshold to identify outliers
# You can adjust this threshold based on your specific requirements
outlier_threshold = 1.5

# Find outliers using the IQR method
outliers = (video_details[column_name] < Q1 - outlier_threshold * IQR) | (video_details[column_name] > Q3 + outlier_threshold * IQR)

# Display the rows containing outliers
outliers_data = video_details[outliers]
print("Rows with outliers:")
print(outliers_data)

# Display summary statistics for the column, including potential outliers
summary_stats = video_details[column_name].describe()
print("\nSummary statistics for the column:")
print(summary_stats)


#To remove outliers


clean_data = '/Users/sankar/Desktop/Project ASD/clean_data.csv'

# Read the CSV file into a DataFrame
clean_data = pd.read_csv(clean_data)

# Specify the column(s) for which you want to remove outliers
# For example, let's consider a column named 'column_name'
column_name = 'probability'

# Calculate the IQR for the specified column
Q1 = clean_data[column_name].quantile(0.25)
Q3 = clean_data[column_name].quantile(0.75)
IQR = Q3 - Q1

# Define a threshold to identify outliers
# You can adjust this threshold based on your specific requirements
outlier_threshold = 1.5

# Identify rows without outliers based on the IQR method
no_outliers = ~((clean_data[column_name] < Q1 - outlier_threshold * IQR) | (clean_data[column_name] > Q3 + outlier_threshold * IQR))

# Create a new DataFrame without outliers
final_data = clean_data[no_outliers]

# Display summary statistics for the column after removing outliers
processed_data = final_data[column_name].describe()
print("\nSummary statistics for the column after removing outliers:")
print(processed_data)

print(final_data)

#Univariate analysis

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load your dataset into a DataFrame
clean_data = pd.read_csv('/Users/sankar/Desktop/Project ASD/clean_data.csv')

# Summary statistics
print(clean_data.describe())

# Histogram
plt.figure(figsize=(10, 6))
sns.histplot(final_data['class_name'], kde=True)
plt.title('Histogram of Variable of class_name')
plt.show()

# Box plot
plt.figure(figsize=(10, 6))
sns.boxplot(x=final_data['duration'])
plt.title('Box Plot of Variable of duration')
plt.show()

#Bivariate analysis
# Scatter plot
plt.figure(figsize=(10, 6))
sns.scatterplot(x='probability', y='duration', data=final_data)
plt.title('Scatter Plot between probability and duration')
plt.show()

# Correlation matrix
correlation_matrix = final_data.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix')
plt.show()

#Multivariate analysis

# Scatterplot matrix
sns.pairplot(final_data, hue='duration', diag_kind='kde')
plt.suptitle('Pairplot of Variables', y=1.02)
plt.show()

# Dimensionality reduction (e.g., Principal Component Analysis)
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Assuming 'features' contains the columns you want to include in the analysis
features = final_data[['uid','probability', 'duration']]
scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)

pca = PCA(n_components=2)
principal_components = pca.fit_transform(scaled_features)

# Create a new DataFrame with the principal components and any relevant categorical information
pc_final_data = pd.DataFrame(data=principal_components, columns=['PC1', 'PC2'])
pc_final_data['uid'] = clean_data['probability']

# Scatter plot of principal components
plt.figure(figsize=(10, 6))
sns.scatterplot(x='PC1', y='PC2', hue='uid', data=pc_final_data)
plt.title('Scatter Plot of Principal Components')
plt.show()



#After EDA

#FIRST MOMENT BUSINESS DECISION

#To calculate MEAN 

final_data.duration.mean()
final_data.probability.mean()
final_data.fps.mean()


#To calculate MEDIAN 
final_data.duration.median()
final_data.probability.median()
final_data.fps.median()


#To calculate MODE 


final_data.duration.mode()
final_data.probability.mode()
final_data.fps.mode()


## SECOND MOMENT BUSINESS DECISION / MEASURES OF DISPERSION

#To find Variance

final_data.duration.var()
final_data.probability.var()
final_data.fps.var()


#To find Standard deviation

final_data.duration.std()
final_data.probability.std()
final_data.fps.std()


#To find Range(Max-Min)

range = max(final_data.duration) - min(final_data.duration)
print(range)

range = max(final_data.probability) - min(final_data.probability)
print(range)

range = max(final_data.fps) - min(final_data.fps)
print(range)


## THIRD MOMENT BUSINESS DECISIONS - Skewness


final_data.duration.skew()
final_data.probability.skew()
final_data.fps.skew()


##FOURTH MOMENT BUSINESS DECISION - Kurtosis

final_data.duration.kurtosis()
final_data.probability.kurtosis()
final_data.fps.kurtosis()



#To save the data from python to folder(CSV format)


import pandas as pd

# Assuming you have a DataFrame named 'your_data'
# Specify the file path
csv_file_path = '/Users/sankar/Desktop/Project ASD/Python documents/final_data.csv'

# Save the DataFrame to a CSV file
final_data.to_csv(csv_file_path, index=False)


#To read

import pandas as pd


final_data = '/Users/sankar/Desktop/Project ASD/Python documents/final_data.csv'

# Read the CSV file into a DataFrame
final_data = pd.read_csv(final_data)

# Install Sweetviz
#pip install sweetviz

import sweetviz as sv

# Create a DataframeReport
report = sv.analyze(final_data)

# Save the report to an HTML file
report.show_html("auto_eda_sweetviz_report.html")


#pip install autoviz

from autoviz.AutoViz_Class import AutoViz_Class

# Load your dataset into a DataFrame
final_data = pd.read_csv('/Users/sankar/Desktop/Project ASD/Python documents/final_data.csv')

# Generate visualizations
AV = AutoViz_Class()
report = AV.AutoViz(final_data)


#pip install pandas-profiling


import pandas as pd
from pandas_profiling import ProfileReport








































































































































































































































































