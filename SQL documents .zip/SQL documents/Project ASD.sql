create database Asdproject;
use ASDproject;
create table data(uid int primary key,asd_project34_video_id int,user_name text,duration double precision,class_name text,probability double precision,fps float,date_time text);
select * from data;
create table video_details(video_id int primary key,name varchar(30),length text);
select * from video_details;
select count(user_name) from data;
select count(name) from video_details;

/*First Moment Business Decision*/
/*To calculate Mean value*/
select AVG(duration) from data;
select AVG(probability) from data;
select AVG(fps) from data;
select AVG(length) from video_details;
/*To calculate Median value*/
select AVG(duration) AS Median
from (
	select duration,ROW_NUMBER() OVER (ORDER BY duration) as row_num,
		COUNT(*) OVER () as total_rows
	from data
) subquery
where row_num = (total_rows + 1 ) / 2
OR row_num = (total_rows + 2 ) / 2;
select AVG(probability) AS Median
from (
	select probability,ROW_NUMBER() OVER (ORDER BY probability) as row_num,
		COUNT(*) OVER () as total_rows
	from data
) subquery
where row_num = (total_rows + 1 ) / 2
OR row_num = (total_rows + 2 ) / 2;
select AVG(fps) AS Median
from (
	select fps,ROW_NUMBER() OVER (ORDER BY fps) as row_num,
		COUNT(*) OVER () as total_rows
	from data
) subquery
where row_num = (total_rows + 1 ) / 2
OR row_num = (total_rows + 2 ) / 2;
select AVG(length) AS Median
from (
	select length,ROW_NUMBER() OVER (ORDER BY length) as row_num,
		COUNT(*) OVER () as total_rows
	from video_details
) subquery
where row_num = (total_rows + 1 ) / 2
OR row_num = (total_rows + 2 ) / 2;
/*To calculate MODE value*/

select duration as mode_duration, count(*) as frequency
from data
GROUP BY duration
ORDER BY frequency DESC
LIMIT 1;

select probability as mode_probability, count(*) as frequency
from data
GROUP BY probability
ORDER BY frequency DESC
LIMIT 1;

select fps as mode_fps, count(*) as frequency
from data
GROUP BY fps
ORDER BY frequency DESC
LIMIT 1;

select length as mode_length, count(*) as frequency
from video_details
GROUP BY length
ORDER BY frequency DESC
LIMIT 1;

/*Second Business Moments-Variance,Standard Deviation,Range*/
/* To calculate Variance */

select variance(duration) from data;
select variance(probability) from data;
select variance(fps) from data;
select variance(length) from video_details;

/* To calculate Standard Deviation */

select STDDEV(duration) from data;
select STDDEV(probability) from data;
select STDDEV(fps) from data;
select STDDEV(length) from video_details;

/* To calculate RANGE value (MAX-MIN) */

select Max(duration) - Min(duration) as duration_range from data;
select Max(probability) - Min(probability) as probability_range from data;
select Max(fps) - Min(fps) as fps_range from data;
select Max(length) - Min(length) as length_range from video_details;

/*Third Business Moments-Skewness */
select
	(
		SUM(POWER(duration - (SELECT AVG(duration) from data), 3)) /
        (COUNT(*) * POWER((SELECT STDDEV(duration) from data), 3 ))
	) AS skewness
from data;

select
	(
		SUM(POWER(probability - (SELECT AVG(probability) from data), 3)) /
        (COUNT(*) * POWER((SELECT STDDEV(probability) from data), 3 ))
	) AS skewness
from data;

select
	(
		SUM(POWER(fps - (SELECT AVG(fps) from data), 3)) /
        (COUNT(*) * POWER((SELECT STDDEV(fps) from data), 3 ))
	) AS skewness
from data;

select
	(
		SUM(POWER(length - (SELECT AVG(length) from video_details), 3)) /
        (COUNT(*) * POWER((SELECT STDDEV(length) from video_details), 3 ))
	) AS skewness
from video_details;

/*Fourth Business Moments - Kurtosis*/

select
	(
		SUM(POWER(duration - (SELECT AVG(duration) from data), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(duration) from data), 4 )) - 3
	) AS kurtosis
from data;

select
	(
		SUM(POWER(probability - (SELECT AVG(probability) from data), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(probability) from data), 4 )) - 3
	) AS kurtosis
from data;

select
	(
		SUM(POWER(fps - (SELECT AVG(fps) from data), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(fps) from data), 4 )) - 3
	) AS kurtosis
from data;

select
	(
		SUM(POWER(length - (SELECT AVG(length) from video_details), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(length) from video_details), 4 )) - 3
	) AS kurtosis
from video_details;

/* Handling Missing values */
select
count(*) as total_rows,
sum(case when uid is null then 1 else 0 end) as uid_missing,
sum(case when asd_project34_video_id is null then 1 else 0 end) as asd_project34_video_id_missing,
sum(case when user_name is null then 1 else 0 end) as user_name_missing,
sum(case when duration is null then 1 else 0 end) as duration_missing,
sum(case when class_name is null then 1 else 0 end) as class_name_missing,
sum(case when probability is null then 1 else 0 end) as probability_missing,
sum(case when fps is null then 1 else 0 end) as fps_missing,
sum(case when date_time is null then 1 else 0 end) as date_time_missing
from data;


#Outliers#
WITH ranked_data AS (
    SELECT
        probability,
        NTILE(4) OVER (ORDER BY probability) AS quartile
    FROM data
)
, quartiles AS (
    SELECT
        MAX(CASE WHEN quartile = 1 THEN probability END) AS Q1,
        MAX(CASE WHEN quartile = 3 THEN probability END) AS Q3
    FROM ranked_data
)
SELECT
    Q1 - 1.5 * (Q3 - Q1) AS lower_bound,
    Q3 + 1.5 * (Q3 - Q1) AS upper_bound,
    Q3 - Q1 AS IQR
FROM quartiles;

select*from data where probability > 1.19218389 or probability< 0.6795412500000002;	
select count(*) from data where probability > 1.19218389 or probability< 0.6795412500000002;
select count(*) from data;
#Identify and remove outliers#

-- Calculate quartiles and IQR
WITH ranked_data AS (
    SELECT
        probability,
        NTILE(4) OVER (ORDER BY probability) AS quartile
    FROM data
)
, quartiles AS (
    SELECT
        MAX(CASE WHEN quartile = 1 THEN probability END) AS Q1,
        MAX(CASE WHEN quartile = 3 THEN probability END) AS Q3
    FROM ranked_data
)
SELECT
    Q1 - 1.5 * (Q3 - Q1) AS lower_bound,
    Q3 + 1.5 * (Q3 - Q1) AS upper_bound,
    Q3 - Q1 AS IQR
FROM quartiles;

-- Remove outliers
DELETE FROM data
WHERE probability > 1.19218389 OR probability < 0.6795412500000002;

select count(*) from data;

CREATE TABLE clean_data AS
SELECT * FROM data
WHERE probability <= 1.19218389 AND probability >= 0.6795412500000002;

SELECT * FROM clean_data;
COMMIT;

#After EDA#

create table data(uid int primary key,asd_project34_video_id int,user_name text,duration double precision,class_name text,probability double precision,fps float,date_time text);
select * from clean_data;

select count(user_name) from clean_data;


/*First Moment Business Decision*/
/*To calculate Mean value*/
select AVG(duration) from clean_data;
select AVG(probability) from clean_data;
select AVG(fps) from clean_data;
/*To calculate Median value*/
select AVG(duration) AS Median
from (
	select duration,ROW_NUMBER() OVER (ORDER BY duration) as row_num,
		COUNT(*) OVER () as total_rows
	from clean_data
) subquery
where row_num = (total_rows + 1 ) / 2
OR row_num = (total_rows + 2 ) / 2;
select AVG(probability) AS Median
from (
	select probability,ROW_NUMBER() OVER (ORDER BY probability) as row_num,
		COUNT(*) OVER () as total_rows
	from clean_data
) subquery
where row_num = (total_rows + 1 ) / 2
OR row_num = (total_rows + 2 ) / 2;
select AVG(fps) AS Median
from (
	select fps,ROW_NUMBER() OVER (ORDER BY fps) as row_num,
		COUNT(*) OVER () as total_rows
	from clean_data
) subquery
where row_num = (total_rows + 1 ) / 2
OR row_num = (total_rows + 2 ) / 2;

/*To calculate MODE value*/

select duration as mode_duration, count(*) as frequency
from clean_data
GROUP BY duration
ORDER BY frequency DESC
LIMIT 1;

select probability as mode_probability, count(*) as frequency
from clean_data
GROUP BY probability
ORDER BY frequency DESC
LIMIT 1;

select fps as mode_fps, count(*) as frequency
from clean_data
GROUP BY fps
ORDER BY frequency DESC
LIMIT 1;

/*Second Business Moments-Variance,Standard Deviation,Range*/
/* To calculate Variance */

select variance(duration) from clean_data;
select variance(probability) from clean_data;
select variance(fps) from clean_data;


/* To calculate Standard Deviation */

select STDDEV(duration) from clean_data;
select STDDEV(probability) from clean_data;
select STDDEV(fps) from clean_data;


/* To calculate RANGE value (MAX-MIN) */

select Max(duration) - Min(duration) as duration_range from clean_data;
select Max(probability) - Min(probability) as probability_range from clean_data;
select Max(fps) - Min(fps) as fps_range from clean_data;


/*Third Business Moments-Skewness */
select
	(
		SUM(POWER(duration - (SELECT AVG(duration) from clean_data), 3)) /
        (COUNT(*) * POWER((SELECT STDDEV(duration) from clean_data), 3 ))
	) AS skewness
from clean_data;

select
	(
		SUM(POWER(probability - (SELECT AVG(probability) from clean_data), 3)) /
        (COUNT(*) * POWER((SELECT STDDEV(probability) from clean_data), 3 ))
	) AS skewness
from clean_data;

select
	(
		SUM(POWER(fps - (SELECT AVG(fps) from clean_data), 3)) /
        (COUNT(*) * POWER((SELECT STDDEV(fps) from clean_data), 3 ))
	) AS skewness
from clean_data;


/*Fourth Business Moments - Kurtosis*/

select
	(
		SUM(POWER(duration - (SELECT AVG(duration) from clean_data), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(duration) from clean_data), 4 )) - 3
	) AS kurtosis
from clean_data;

select
	(
		SUM(POWER(probability - (SELECT AVG(probability) from clean_data), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(probability) from clean_data), 4 )) - 3
	) AS kurtosis
from clean_data;

select
	(
		SUM(POWER(fps - (SELECT AVG(fps) from clean_data), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(fps) from clean_data), 4 )) - 3
	) AS kurtosis
from clean_data;
